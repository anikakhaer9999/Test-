import javax.print.DocFlavor;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.Scanner;
public class AdressBook extends JFrame {
   public JTextField name , phone , email , streetaddress , searchresultshow;
    public JButton search , save , viewall ;
    public AdressBook() {
        File file  = new File( "Information.txt");
        setSize(400,600);
        setTitle("Adress Book");
        setResizable(false);
        JPanel jPanel = new JPanel();
        JTextArea j = new JTextArea(15,35);
        JLabel jLabel = new JLabel("Name");
        JLabel jLabel1 = new JLabel ("Phone no");
        JLabel jLabel2 = new JLabel("Email");
        JLabel jLabel3 = new JLabel("Street Adress");
        JLabel jLabel4 = new JLabel("Input Name");
        name = new JTextField(35);
        phone = new JTextField(35);
        email = new JTextField(35);
        streetaddress = new JTextField(35);
        searchresultshow = new JTextField(35);
        jPanel.add(jLabel);
        jPanel.add(name);
        jPanel.add(jLabel1);
        jPanel.add(phone);
        jPanel.add(jLabel2);
        jPanel.add(email);
        jPanel.add(jLabel3);
        jPanel.add(streetaddress);
        search = new JButton("Search");
        search.setBounds(90, 60, 100, 50);//x=graph er point
        save= new JButton("Save");
        save.setBounds(90, 60, 100, 50);
        viewall= new JButton("View All");
        viewall.setBounds(90, 60, 100, 50);
        jPanel.add(save);
        save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String n = name.getText();
                String p = phone.getText();
                String f = email.getText();
                String s = streetaddress.getText();
                try {
                    FileWriter fileWriter = new FileWriter(file, true);
                    fileWriter.append(n + "," + p + "," + f + "," + s + "\n");//appened mane write korafi
                    fileWriter.close(); //j kono block e lekhar policy ,writer clod=se miust
                }
                catch (FileNotFoundException a) {
                }
                catch (IOException a) {  // ata file wrier er exception
                }
            }
        });
        jPanel.add(search);
        search.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String inputn = searchresultshow.getText();
                j.setText("");
                try {
                    Scanner scanner = new Scanner(file);
                    while (scanner.hasNextLine()){
                        String show = scanner.nextLine();   // scanner er line reader (ALL TYPE )
                        String[] arr = show.split(",");
                        if(inputn.equals(arr[0])){ // ekhane name k arr index er sthate line up
                            j.append(show + "\n");
                        }
                    }
                } catch (FileNotFoundException d) {
                }
            }
        });
        jPanel.add(viewall);
        viewall.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                j.setText("");// blank korar jonnow
                try {
                    Scanner scanner = new Scanner(file);
                  while (scanner.hasNextLine()){
                      String show = scanner.nextLine(); // scanner er line reader (ALL TYPE )
                      j.append(show + "\n");
                  }
                } catch (FileNotFoundException d) {
                }
            }
        });
        jPanel.add(searchresultshow);
        jPanel.add(jLabel4);
        jPanel.add(j);
        add(jPanel);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public static void main(String[] args) {
        AdressBook adressBook = new AdressBook();

    }
}